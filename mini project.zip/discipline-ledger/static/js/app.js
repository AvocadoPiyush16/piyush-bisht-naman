// 1. Confirm before destructive actions: <form data-confirm="Are you sure?">
document.querySelectorAll("form[data-confirm]").forEach(function (form) {
  form.addEventListener("submit", function (e) {
    if (!window.confirm(form.dataset.confirm)) e.preventDefault();
  });
});

// 2. Click a chart to enlarge it, click again (or press Esc) to close.
document.querySelectorAll("img[data-zoom]").forEach(function (img) {
  img.addEventListener("click", function () {
    var overlay = document.createElement("div");
    overlay.className = "overlay";
    var big = document.createElement("img");
    big.src = img.src;
    big.alt = img.alt;
    overlay.appendChild(big);
    function close() { overlay.remove(); document.removeEventListener("keydown", onKey); }
    function onKey(e) { if (e.key === "Escape") close(); }
    overlay.addEventListener("click", close);
    document.addEventListener("keydown", onKey);
    document.body.appendChild(overlay);
  });
});
