"""Activity tracking: create, list (with category filter), edit, delete."""
from datetime import date
from flask import Blueprint, render_template, request, redirect, url_for, session, flash, abort

from database.db import query, execute
from utils.decorators import login_required
from utils.validators import validate_activity, CATEGORIES

bp = Blueprint("activities", __name__, url_prefix="/activities")


def _render(form, editing=None):
    uid = session["user_id"]
    category = request.args.get("category", "")
    if category in CATEGORIES:
        rows = query("SELECT * FROM activities WHERE user_id=%s AND category=%s "
                     "ORDER BY activity_date DESC, id DESC LIMIT 200", (uid, category))
    else:
        category = ""
        rows = query("SELECT * FROM activities WHERE user_id=%s "
                     "ORDER BY activity_date DESC, id DESC LIMIT 200", (uid,))
    return render_template("activities.html", activities=rows, form=form, editing=editing,
                           categories=CATEGORIES, selected_category=category)


@bp.route("/", methods=["GET", "POST"])
@login_required
def index():
    if request.method == "POST":
        errors, data = validate_activity(request.form.get("category"), request.form.get("duration"),
                                         request.form.get("activity_date"), request.form.get("description"))
        if errors:
            for e in errors:
                flash(e, "error")
            return _render(request.form)
        execute("INSERT INTO activities (user_id, category, duration_minutes, activity_date, description) "
                "VALUES (%s,%s,%s,%s,%s)",
                (session["user_id"], data["category"], data["duration_minutes"],
                 data["activity_date"], data["description"]))
        flash("Activity logged.", "success")
        return redirect(url_for("activities.index"))
    return _render({"activity_date": date.today().isoformat()})


@bp.route("/<int:activity_id>/edit", methods=["GET", "POST"])
@login_required
def edit(activity_id):
    # user_id in the WHERE clause stops users touching each other's records
    record = query("SELECT * FROM activities WHERE id=%s AND user_id=%s",
                   (activity_id, session["user_id"]), one=True)
    if not record:
        abort(404)
    if request.method == "POST":
        errors, data = validate_activity(request.form.get("category"), request.form.get("duration"),
                                         request.form.get("activity_date"), request.form.get("description"))
        if errors:
            for e in errors:
                flash(e, "error")
            return _render(request.form, editing=record)
        execute("UPDATE activities SET category=%s, duration_minutes=%s, activity_date=%s, description=%s "
                "WHERE id=%s AND user_id=%s",
                (data["category"], data["duration_minutes"], data["activity_date"],
                 data["description"], activity_id, session["user_id"]))
        flash("Activity updated.", "success")
        return redirect(url_for("activities.index"))
    record["duration"] = record["duration_minutes"]
    return _render(record, editing=record)


@bp.route("/<int:activity_id>/delete", methods=["POST"])
@login_required
def delete(activity_id):
    execute("DELETE FROM activities WHERE id=%s AND user_id=%s", (activity_id, session["user_id"]))
    flash("Activity deleted.", "success")
    return redirect(url_for("activities.index"))
