"""Dashboard route. Statistics and charts are built in utils/analytics.py from real DB rows."""
import time
from flask import Blueprint, render_template, session

from utils.decorators import login_required
from utils import analytics as an

bp = Blueprint("analytics", __name__)


@bp.route("/")
@bp.route("/dashboard")
@login_required
def dashboard():
    uid = session["user_id"]
    charts = {
        "weekly": an.weekly_chart(uid),
        "categories": an.category_chart(uid),
        "trend": an.trend_chart(uid),
        "habits": an.habit_chart(uid),
    }
    return render_template("dashboard.html", stats=an.get_stats(uid), charts=charts,
                           version=int(time.time()))  # version busts the browser cache of the PNGs
