"""Task management: create, edit, complete, delete, with deadlines and priorities."""
from datetime import date
from flask import Blueprint, render_template, request, redirect, url_for, session, flash, abort

from database.db import query, execute
from utils.decorators import login_required
from utils.validators import validate_task, PRIORITIES

bp = Blueprint("tasks", __name__, url_prefix="/tasks")


def _render(form, editing=None):
    tasks = query("SELECT * FROM tasks WHERE user_id=%s "
                  "ORDER BY is_completed, deadline IS NULL, deadline, FIELD(priority,'high','medium','low')",
                  (session["user_id"],))
    return render_template("tasks.html", tasks=tasks, form=form, editing=editing,
                           priorities=PRIORITIES, today=date.today())


@bp.route("/", methods=["GET", "POST"])
@login_required
def index():
    if request.method == "POST":
        errors, data = validate_task(request.form.get("title"), request.form.get("deadline"),
                                     request.form.get("priority"))
        if errors:
            for e in errors:
                flash(e, "error")
            return _render(request.form)
        execute("INSERT INTO tasks (user_id, title, deadline, priority) VALUES (%s,%s,%s,%s)",
                (session["user_id"], data["title"], data["deadline"], data["priority"]))
        flash("Task added.", "success")
        return redirect(url_for("tasks.index"))
    return _render({"priority": "medium"})


@bp.route("/<int:task_id>/edit", methods=["GET", "POST"])
@login_required
def edit(task_id):
    record = query("SELECT * FROM tasks WHERE id=%s AND user_id=%s", (task_id, session["user_id"]), one=True)
    if not record:
        abort(404)
    if request.method == "POST":
        errors, data = validate_task(request.form.get("title"), request.form.get("deadline"),
                                     request.form.get("priority"))
        if errors:
            for e in errors:
                flash(e, "error")
            return _render(request.form, editing=record)
        execute("UPDATE tasks SET title=%s, deadline=%s, priority=%s WHERE id=%s AND user_id=%s",
                (data["title"], data["deadline"], data["priority"], task_id, session["user_id"]))
        flash("Task updated.", "success")
        return redirect(url_for("tasks.index"))
    return _render(record, editing=record)


@bp.route("/<int:task_id>/toggle", methods=["POST"])
@login_required
def toggle(task_id):
    execute("UPDATE tasks SET is_completed = NOT is_completed WHERE id=%s AND user_id=%s",
            (task_id, session["user_id"]))
    return redirect(url_for("tasks.index"))


@bp.route("/<int:task_id>/delete", methods=["POST"])
@login_required
def delete(task_id):
    execute("DELETE FROM tasks WHERE id=%s AND user_id=%s", (task_id, session["user_id"]))
    flash("Task deleted.", "success")
    return redirect(url_for("tasks.index"))
