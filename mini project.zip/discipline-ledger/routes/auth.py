"""Registration, login, logout."""
import mysql.connector
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash

from database.db import query, execute
from utils.validators import validate_registration

bp = Blueprint("auth", __name__)


@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        errors = validate_registration(username, email, password, request.form.get("confirm", ""))

        if not errors and query("SELECT id FROM users WHERE username=%s OR email=%s",
                                (username, email), one=True):
            errors.append("That username or email is already registered.")
        if not errors:
            try:
                # Only the salted hash is stored, never the password itself.
                execute("INSERT INTO users (username, email, password_hash) VALUES (%s,%s,%s)",
                        (username, email, generate_password_hash(password)))
            except mysql.connector.IntegrityError:
                errors.append("That username or email is already registered.")
        if errors:
            for e in errors:
                flash(e, "error")
            return render_template("register.html", form=request.form)

        flash("Account created. Log in to start tracking.", "success")
        return redirect(url_for("auth.login"))
    return render_template("register.html", form={})


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        ident = request.form.get("identifier", "").strip()
        password = request.form.get("password", "")
        user = query("SELECT id, username, password_hash FROM users WHERE username=%s OR email=%s",
                     (ident, ident.lower()), one=True)
        if user and check_password_hash(user["password_hash"], password):
            session.clear()  # drop any old session data (prevents session fixation)
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            return redirect(url_for("analytics.dashboard"))
        flash("Incorrect username/email or password.", "error")  # same message for both cases
        return render_template("login.html", form=request.form)
    return render_template("login.html", form={})


@bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("auth.login"))
