"""Habit tracking: create habits, tick days, completion %, streaks."""
import mysql.connector
from datetime import date, timedelta
from flask import Blueprint, render_template, request, redirect, url_for, session, flash, abort

from database.db import query, execute
from utils.decorators import login_required
from utils.validators import validate_habit_name, parse_date
from utils.calculations import completion_pct, current_streak

bp = Blueprint("habits", __name__, url_prefix="/habits")


@bp.route("/", methods=["GET", "POST"])
@login_required
def index():
    uid = session["user_id"]
    if request.method == "POST":
        errors, name = validate_habit_name(request.form.get("name"))
        if not errors and query("SELECT id FROM habits WHERE user_id=%s AND name=%s", (uid, name), one=True):
            errors.append("You already track a habit with that name.")
        if errors:
            for e in errors:
                flash(e, "error")
        else:
            try:
                execute("INSERT INTO habits (user_id, name, created_at) VALUES (%s,%s,%s)",
                        (uid, name, date.today()))
                flash("Habit created.", "success")
            except mysql.connector.IntegrityError:
                flash("You already track a habit with that name.", "error")
        return redirect(url_for("habits.index"))

    today = date.today()
    week = [today - timedelta(days=i) for i in range(6, -1, -1)]
    habits = query("SELECT id, name, created_at FROM habits WHERE user_id=%s AND is_active=1 ORDER BY id", (uid,))
    for h in habits:  # one small query per habit is fine at this scale
        done = {r["log_date"] for r in query("SELECT log_date FROM habit_logs WHERE habit_id=%s", (h["id"],))}
        possible = (today - h["created_at"]).days + 1
        h["total"], h["possible"] = len(done), possible
        h["pct"] = completion_pct(len(done), possible)
        h["streak"] = current_streak(done, today)
        h["week"] = [(d, d in done, d < h["created_at"]) for d in week]  # (date, done?, before creation?)
    return render_template("habits.html", habits=habits)


@bp.route("/<int:habit_id>/toggle", methods=["POST"])
@login_required
def toggle(habit_id):
    habit = query("SELECT id, created_at FROM habits WHERE id=%s AND user_id=%s",
                  (habit_id, session["user_id"]), one=True)
    if not habit:
        abort(404)
    day = parse_date(request.form.get("date"))
    if day is None or day > date.today() or day < habit["created_at"]:
        flash("That date can't be changed for this habit.", "error")
        return redirect(url_for("habits.index"))
    existing = query("SELECT id FROM habit_logs WHERE habit_id=%s AND log_date=%s", (habit_id, day), one=True)
    if existing:
        execute("DELETE FROM habit_logs WHERE id=%s", (existing["id"],))
    else:
        try:
            execute("INSERT INTO habit_logs (habit_id, log_date) VALUES (%s,%s)", (habit_id, day))
        except mysql.connector.IntegrityError:
            pass  # double-click race: already logged, UNIQUE key protected us
    return redirect(url_for("habits.index"))


@bp.route("/<int:habit_id>/delete", methods=["POST"])
@login_required
def delete(habit_id):
    execute("DELETE FROM habits WHERE id=%s AND user_id=%s", (habit_id, session["user_id"]))  # logs cascade
    flash("Habit deleted.", "success")
    return redirect(url_for("habits.index"))
