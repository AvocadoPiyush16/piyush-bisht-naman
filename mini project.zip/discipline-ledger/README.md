# Discipline Ledger

A Flask + MySQL web app for tracking daily activities, habits and tasks, with Matplotlib analytics built from your own records.

## Features
- Register / log in (salted password hashes, sessions, CSRF protection)
- Activities: log study, coding, workout and other time; edit, delete, filter by category
- Habits: create habits, tick any of the last 7 days, completion % and current streak
- Tasks: deadlines, priorities, overdue flag, mark done, edit, delete
- Dashboard: total study / coding / workout hours, completed tasks, habit completion %, today / 7-day average, and four Matplotlib charts (weekly stacked bars, 30-day trend, category donut, habit completion). Click a chart to enlarge it.

## Setup
```bash
git clone <your-repo-url> discipline-ledger && cd discipline-ledger
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt

# 1. Create the database (MySQL 8.0.16+)
mysql -u root -p < database/schema.sql

# 2. Configure secrets
cp .env.example .env        # then edit .env: SECRET_KEY and your MySQL password
python -c "import secrets; print(secrets.token_hex(32))"   # use this for SECRET_KEY

# 3. Run
python app.py               # open http://127.0.0.1:5000
```

## Tests
```bash
pytest
```
Unit tests cover input validation and the habit percentage / streak calculations.

## Project structure
| Path | Purpose |
|---|---|
| `app.py` | App factory, CSRF check, error handlers |
| `config.py` | Reads settings from `.env` |
| `database/` | `schema.sql` and `db.py` (parameterized query helpers) |
| `routes/` | One Flask Blueprint per module |
| `utils/` | Validators, calculations, analytics and charts, login decorator |
| `templates/`, `static/` | Jinja pages, CSS, JS, generated chart PNGs |
| `tests/` | Pytest unit tests |
| `docs/project_report.md` | College report |

## Security notes
- SQL: every query uses `%s` parameters; user_id is always part of the WHERE clause.
- Passwords: `werkzeug.security` hashes; plain passwords are never stored.
- Secrets: `.env` is git-ignored; only `.env.example` is committed.

## Screenshots
Run the app, add some data, and save screenshots of each page into `screenshots/` (login, dashboard, activities, habits, tasks). Reference them here before submitting.

## Contributors
- **Piyush Bisht**: architecture, Flask backend, MySQL design, activities, habits, analytics/Matplotlib, integration, GitHub, testing
- **Naman**: HTML/CSS assistance, tasks module assistance, UI testing and bug reports, screenshots, README/docs assistance
