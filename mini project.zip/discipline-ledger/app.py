"""Application factory: creates the Flask app, registers blueprints and security hooks."""
import secrets
import mysql.connector
from flask import Flask, session, request, abort, render_template

from config import Config
from database import db


def create_app():
    Config.validate()
    app = Flask(__name__)
    app.config.from_object(Config)
    app.teardown_appcontext(db.close_db)

    from routes import auth, activities, habits, tasks, analytics
    for module in (auth, activities, habits, tasks, analytics):
        app.register_blueprint(module.bp)

    @app.before_request
    def csrf_protect():
        """Reject any POST whose hidden csrf_token doesn't match the session's token."""
        if request.method == "POST":
            token = session.get("csrf_token")
            if not token or token != request.form.get("csrf_token"):
                abort(400)

    @app.context_processor
    def inject_helpers():
        def csrf_token():
            if "csrf_token" not in session:
                session["csrf_token"] = secrets.token_hex(16)
            return session["csrf_token"]
        return {"csrf_token": csrf_token}

    @app.template_filter("hm")
    def minutes_to_hm(minutes):
        hours, mins = divmod(int(minutes), 60)
        return f"{hours}h {mins:02d}m" if hours else f"{mins}m"

    def show_error(code, message):
        return render_template("error.html", code=code, message=message), code

    @app.errorhandler(400)
    def bad_request(e):
        return show_error(400, "The request could not be verified. Reload the page and try again.")

    @app.errorhandler(404)
    def not_found(e):
        return show_error(404, "That page or record does not exist.")

    @app.errorhandler(mysql.connector.Error)
    def database_error(e):
        app.logger.error("Database error: %s", e)
        return show_error(500, "Database error. Check that MySQL is running and your .env is correct.")

    return app


if __name__ == "__main__":
    create_app().run(debug=True)
