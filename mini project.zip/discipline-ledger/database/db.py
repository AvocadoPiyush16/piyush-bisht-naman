"""Database layer. Every query in the app goes through query()/execute(),
which always take parameters separately (%s placeholders) -> no SQL injection."""
import mysql.connector
from flask import g, current_app


def get_db():
    """One connection per request, stored on Flask's `g` object."""
    if "db" not in g:
        g.db = mysql.connector.connect(**current_app.config["DB_CONFIG"])
    return g.db


def close_db(exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def query(sql, params=(), one=False):
    """Run a SELECT. Returns list of dicts, or a single dict/None when one=True."""
    cur = get_db().cursor(dictionary=True)
    try:
        cur.execute(sql, params)
        rows = cur.fetchall()
    finally:
        cur.close()
    if one:
        return rows[0] if rows else None
    return rows


def execute(sql, params=()):
    """Run INSERT/UPDATE/DELETE. Commits on success, rolls back on error."""
    db = get_db()
    cur = db.cursor()
    try:
        cur.execute(sql, params)
        db.commit()
        return cur.lastrowid
    except mysql.connector.Error:
        db.rollback()
        raise
    finally:
        cur.close()
