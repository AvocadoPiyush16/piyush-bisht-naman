-- Discipline Ledger schema (MySQL 8.0.16+ so CHECK constraints are enforced)
CREATE DATABASE IF NOT EXISTS discipline_ledger
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE discipline_ledger;

CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(50)  NOT NULL UNIQUE,
  email         VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,           -- never the plain password
  created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS activities (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  user_id          INT NOT NULL,
  category         ENUM('study','coding','workout','other') NOT NULL,
  duration_minutes INT NOT NULL,
  activity_date    DATE NOT NULL,
  description      VARCHAR(255) NULL,
  CONSTRAINT chk_duration CHECK (duration_minutes BETWEEN 1 AND 1440),
  CONSTRAINT fk_activity_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_activity_user_date (user_id, activity_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS habits (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  name       VARCHAR(100) NOT NULL,
  created_at DATE NOT NULL,
  is_active  BOOLEAN NOT NULL DEFAULT TRUE,
  CONSTRAINT fk_habit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_habit_user_name (user_id, name)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS habit_logs (
  id       INT AUTO_INCREMENT PRIMARY KEY,
  habit_id INT  NOT NULL,
  log_date DATE NOT NULL,
  CONSTRAINT fk_log_habit FOREIGN KEY (habit_id) REFERENCES habits(id) ON DELETE CASCADE,
  UNIQUE KEY uq_habit_day (habit_id, log_date)   -- a habit can be completed once per day
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tasks (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  user_id      INT NOT NULL,
  title        VARCHAR(150) NOT NULL,
  deadline     DATE NULL,
  priority     ENUM('low','medium','high') NOT NULL DEFAULT 'medium',
  is_completed BOOLEAN NOT NULL DEFAULT FALSE,
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_task_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_task_user (user_id, is_completed, deadline)
) ENGINE=InnoDB;
