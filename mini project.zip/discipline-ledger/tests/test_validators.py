from datetime import date, timedelta
from utils.validators import (validate_registration, validate_activity, validate_task,
                              validate_habit_name, parse_date)
from utils.calculations import completion_pct, current_streak


def test_registration_valid():
    assert validate_registration("piyush_1", "a@b.com", "abcd1234", "abcd1234") == []


def test_registration_rejects_bad_input():
    errors = validate_registration("x", "bad", "short", "other")
    assert len(errors) == 4


def test_activity_valid():
    errors, data = validate_activity("study", "90", date.today().isoformat(), " Python ")
    assert errors == [] and data["duration_minutes"] == 90 and data["description"] == "Python"


def test_activity_rejects_future_date_and_bad_duration():
    future = (date.today() + timedelta(days=1)).isoformat()
    errors, _ = validate_activity("sleep", "0", future, "")
    assert len(errors) == 3


def test_task_deadline_optional_and_priority_checked():
    errors, data = validate_task("Submit report", "", "high")
    assert errors == [] and data["deadline"] is None
    errors, _ = validate_task("", "2026-13-40", "urgent")
    assert len(errors) == 3


def test_habit_name():
    assert validate_habit_name("  ")[0]
    assert validate_habit_name("Read")[0] == []


def test_parse_date():
    assert parse_date("2026-11-18") == date(2026, 11, 18)
    assert parse_date("nope") is None


def test_completion_pct_caps_and_handles_zero():
    assert completion_pct(5, 10) == 50.0
    assert completion_pct(12, 10) == 100.0
    assert completion_pct(1, 0) == 0.0


def test_streak_counts_back_from_today_or_yesterday():
    today = date(2026, 11, 18)
    done = {today, today - timedelta(days=1), today - timedelta(days=2)}
    assert current_streak(done, today) == 3
    assert current_streak({today - timedelta(days=1)}, today) == 1   # today not done yet
    assert current_streak({today - timedelta(days=3)}, today) == 0
