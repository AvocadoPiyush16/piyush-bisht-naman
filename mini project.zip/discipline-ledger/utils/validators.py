"""Server-side input validation. Each function returns error messages (empty = valid)."""
import re
from datetime import datetime, date

CATEGORIES = ("study", "coding", "workout", "other")
PRIORITIES = ("low", "medium", "high")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,30}$")


def parse_date(value):
    """'YYYY-MM-DD' -> date, or None if invalid."""
    try:
        return datetime.strptime((value or "").strip(), "%Y-%m-%d").date()
    except ValueError:
        return None


def validate_registration(username, email, password, confirm):
    errors = []
    if not USERNAME_RE.match(username):
        errors.append("Username must be 3-30 characters: letters, numbers, underscore.")
    if not EMAIL_RE.match(email) or len(email) > 120:
        errors.append("Enter a valid email address.")
    if len(password) < 8 or not any(c.isalpha() for c in password) or not any(c.isdigit() for c in password):
        errors.append("Password must be at least 8 characters with a letter and a number.")
    if password != confirm:
        errors.append("Passwords do not match.")
    return errors


def validate_activity(category, duration, date_str, description):
    """Returns (errors, cleaned_data)."""
    errors = []
    if category not in CATEGORIES:
        errors.append("Choose a valid category.")
    try:
        minutes = int(duration)
    except (TypeError, ValueError):
        minutes = None
    if minutes is None or not 1 <= minutes <= 1440:
        errors.append("Duration must be a whole number of minutes between 1 and 1440.")
    when = parse_date(date_str)
    if when is None:
        errors.append("Enter a valid date.")
    elif when > date.today():
        errors.append("Activity date cannot be in the future.")
    description = (description or "").strip()
    if len(description) > 255:
        errors.append("Description must be 255 characters or fewer.")
    return errors, {"category": category, "duration_minutes": minutes,
                    "activity_date": when, "description": description or None}


def validate_task(title, deadline, priority):
    """Returns (errors, cleaned_data). Deadline is optional."""
    errors = []
    title = (title or "").strip()
    if not title or len(title) > 150:
        errors.append("Task title is required (max 150 characters).")
    due = None
    if (deadline or "").strip():
        due = parse_date(deadline)
        if due is None:
            errors.append("Enter a valid deadline date.")
    if priority not in PRIORITIES:
        errors.append("Choose a valid priority.")
    return errors, {"title": title, "deadline": due, "priority": priority}


def validate_habit_name(name):
    name = (name or "").strip()
    errors = [] if 1 <= len(name) <= 100 else ["Habit name is required (max 100 characters)."]
    return errors, name
