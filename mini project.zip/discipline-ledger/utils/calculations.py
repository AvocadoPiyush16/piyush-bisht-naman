"""Pure calculation helpers (no database) so they are easy to unit test."""
from datetime import timedelta


def completion_pct(done, possible):
    """Percentage of possible days a habit was completed, capped at 100."""
    if possible <= 0:
        return 0.0
    return round(min(done / possible * 100, 100), 1)


def current_streak(done_dates, today):
    """Consecutive completed days ending today (or yesterday if today isn't done yet)."""
    day = today if today in done_dates else today - timedelta(days=1)
    streak = 0
    while day in done_dates:
        streak += 1
        day -= timedelta(days=1)
    return streak
