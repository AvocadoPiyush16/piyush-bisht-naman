"""Statistics + Matplotlib charts. Everything is computed from the user's database records."""
import os
from datetime import date, timedelta

import matplotlib
matplotlib.use("Agg")  # render to files, no display needed on a server
import matplotlib.pyplot as plt
from flask import current_app

from database.db import query
from utils.calculations import completion_pct
from utils.validators import CATEGORIES

BG, PANEL, FG, GRID = "#0d1117", "#161b22", "#c9d1d9", "#30363d"
COLORS = {"study": "#58a6ff", "coding": "#3fb950", "workout": "#f0883e", "other": "#a371f7"}
WINDOW_DAYS = 30


# ---------- data queries ----------

def _minutes_by_day_and_category(uid, start, end):
    return query("SELECT activity_date AS d, category AS c, SUM(duration_minutes) AS m FROM activities "
                 "WHERE user_id=%s AND activity_date BETWEEN %s AND %s GROUP BY activity_date, category",
                 (uid, start, end))


def habit_completion(uid, days=WINDOW_DAYS):
    """Per-habit completion % over the last `days` days (or since the habit was created)."""
    today = date.today()
    start = today - timedelta(days=days - 1)
    rows = query("SELECT h.id, h.name, h.created_at, "
                 "(SELECT COUNT(*) FROM habit_logs l WHERE l.habit_id=h.id AND l.log_date BETWEEN %s AND %s) AS done "
                 "FROM habits h WHERE h.user_id=%s AND h.is_active=1", (start, today, uid))
    result = []
    for r in rows:
        possible = (today - max(r["created_at"], start)).days + 1
        result.append({"name": r["name"], "done": int(r["done"]), "possible": possible,
                       "pct": completion_pct(int(r["done"]), possible)})
    return result


def get_stats(uid):
    today = date.today()
    hours = {c: 0.0 for c in CATEGORIES}
    for r in query("SELECT category, SUM(duration_minutes) AS m FROM activities WHERE user_id=%s GROUP BY category", (uid,)):
        hours[r["category"]] = round(float(r["m"]) / 60, 1)

    t = query("SELECT SUM(is_completed=1) AS done, SUM(is_completed=0) AS pending FROM tasks WHERE user_id=%s",
              (uid,), one=True)

    week_start = today - timedelta(days=6)
    per_day = {}
    for r in _minutes_by_day_and_category(uid, week_start, today):
        per_day[r["d"]] = per_day.get(r["d"], 0) + int(r["m"])
    week_total = sum(per_day.values())
    best_day = max(per_day, key=per_day.get) if per_day else None

    habits = habit_completion(uid)
    done, possible = sum(h["done"] for h in habits), sum(h["possible"] for h in habits)

    return {
        "hours": hours,
        "tasks_done": int(t["done"] or 0), "tasks_pending": int(t["pending"] or 0),
        "habit_pct": completion_pct(done, possible), "habit_count": len(habits),
        "today_minutes": per_day.get(today, 0),
        "avg_minutes_7d": round(week_total / 7),
        "best_day": best_day, "best_day_minutes": per_day.get(best_day, 0) if best_day else 0,
        "has_activity": any(hours.values()),
    }


# ---------- chart helpers ----------

def _new_figure(width=6.4, height=3.4):
    fig, ax = plt.subplots(figsize=(width, height))
    fig.patch.set_facecolor(PANEL)
    ax.set_facecolor(PANEL)
    ax.tick_params(colors=FG, labelsize=8)
    for spine in ax.spines.values():
        spine.set_color(GRID)
    ax.grid(axis="y", color=GRID, linewidth=0.6, alpha=0.7)
    ax.set_axisbelow(True)
    return fig, ax


def _save(fig, uid, name):
    folder = os.path.join(current_app.static_folder, "charts")
    os.makedirs(folder, exist_ok=True)
    filename = f"u{uid}_{name}.png"
    fig.savefig(os.path.join(folder, filename), dpi=120, facecolor=PANEL, bbox_inches="tight")
    plt.close(fig)
    return f"charts/{filename}"


# ---------- charts (each returns a static-relative path, or None when there is no data) ----------

def weekly_chart(uid):
    """Stacked bars: hours per day for the last 7 days, split by category."""
    today = date.today()
    days = [today - timedelta(days=i) for i in range(6, -1, -1)]
    rows = _minutes_by_day_and_category(uid, days[0], today)
    if not rows:
        return None
    data = {c: [0.0] * 7 for c in CATEGORIES}
    for r in rows:
        data[r["c"]][days.index(r["d"])] = float(r["m"]) / 60
    fig, ax = _new_figure()
    bottom = [0.0] * 7
    labels = [d.strftime("%a %d") for d in days]
    for c in CATEGORIES:
        ax.bar(labels, data[c], bottom=bottom, color=COLORS[c], label=c.capitalize(), width=0.6)
        bottom = [b + v for b, v in zip(bottom, data[c])]
    ax.set_ylabel("Hours", color=FG, fontsize=9)
    ax.set_title("Weekly activity", color=FG, fontsize=11, loc="left")
    ax.legend(facecolor=PANEL, edgecolor=GRID, labelcolor=FG, fontsize=8, ncol=4, loc="upper left")
    return _save(fig, uid, "weekly")


def category_chart(uid):
    """Donut: share of total time per category (all time)."""
    rows = query("SELECT category, SUM(duration_minutes) AS m FROM activities WHERE user_id=%s GROUP BY category", (uid,))
    if not rows:
        return None
    fig, ax = plt.subplots(figsize=(4.2, 3.4))
    fig.patch.set_facecolor(PANEL)
    ax.pie([float(r["m"]) for r in rows], labels=[r["category"].capitalize() for r in rows],
           colors=[COLORS[r["category"]] for r in rows], autopct="%1.0f%%", startangle=90,
           wedgeprops={"width": 0.42, "edgecolor": PANEL}, textprops={"color": FG, "fontsize": 8},
           pctdistance=0.78)
    ax.set_title("Time by category", color=FG, fontsize=11, loc="left")
    return _save(fig, uid, "categories")


def trend_chart(uid):
    """Line: total hours per day over the last 30 days."""
    today = date.today()
    days = [today - timedelta(days=i) for i in range(WINDOW_DAYS - 1, -1, -1)]
    rows = _minutes_by_day_and_category(uid, days[0], today)
    if not rows:
        return None
    totals = {d: 0.0 for d in days}
    for r in rows:
        totals[r["d"]] += float(r["m"]) / 60
    fig, ax = _new_figure()
    ax.plot(days, [totals[d] for d in days], color=COLORS["study"], linewidth=2)
    ax.fill_between(days, [totals[d] for d in days], color=COLORS["study"], alpha=0.15)
    ax.set_ylabel("Hours", color=FG, fontsize=9)
    ax.set_title("Daily productivity, last 30 days", color=FG, fontsize=11, loc="left")
    fig.autofmt_xdate()
    return _save(fig, uid, "trend")


def habit_chart(uid):
    """Horizontal bars: completion % per habit over the last 30 days."""
    habits = habit_completion(uid)
    if not habits:
        return None
    fig, ax = _new_figure(height=max(2.2, 0.55 * len(habits) + 1.2))
    ax.grid(axis="x", color=GRID, linewidth=0.6, alpha=0.7)
    ax.grid(axis="y", visible=False)
    ax.barh([h["name"] for h in habits], [h["pct"] for h in habits], color=COLORS["coding"], height=0.5)
    ax.set_xlim(0, 100)
    ax.set_xlabel("Completion %", color=FG, fontsize=9)
    ax.set_title("Habit completion, last 30 days", color=FG, fontsize=11, loc="left")
    return _save(fig, uid, "habits")
