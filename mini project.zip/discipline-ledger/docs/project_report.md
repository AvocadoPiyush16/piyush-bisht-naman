# Discipline Ledger: Personal Productivity and Performance Analytics System

**BCA Mini Project**
**Team:** Piyush Bisht (Primary Developer), Naman (Supporting Developer)
**Institution / Guide / Session:** _fill in before submission_

## 1. Abstract
Discipline Ledger is a web application that lets a user record daily activities, track habits, manage tasks and view analytics of their consistency. It is built with Flask, MySQL and Matplotlib. All dashboard figures and charts are computed from stored database records.

## 2. Introduction
Many students track routines in scattered notes or memory. This project provides one place to log time, check off habits and manage deadlines, and shows the results as statistics and charts.

## 3. Problem statement
Existing to-do or habit apps either track only one thing or hide the data behind paid plans. There is no simple self-hosted tool that combines time logs, habits and tasks with analytics over real history.

## 4. Objectives
1. Secure registration and login.
2. Record activities by category, duration and date.
3. Track habits and compute completion percentage and streak.
4. Manage tasks with deadlines and priorities.
5. Show totals and charts generated from database records.

## 5. Technologies used
Python 3, Flask, Jinja2, HTML5, CSS3, JavaScript, MySQL, mysql-connector-python, Matplotlib, python-dotenv, Git/GitHub, pytest.

## 6. System requirements
- Hardware: any computer with 4 GB RAM.
- Software: Python 3.10+, MySQL 8.0.16+, a modern browser.

## 7. System architecture
Browser → Flask routes (Blueprints) → database layer (`database/db.py`) → MySQL. The analytics module reads the database and writes PNG charts to `static/charts`, which the dashboard displays.
- **Routes:** HTTP handling only (auth, activities, habits, tasks, analytics).
- **Utils:** validation, calculations, analytics, login decorator.
- **Templates/static:** Jinja pages, CSS, JavaScript.
- **App factory:** `create_app()` registers blueprints, CSRF protection and error handlers.

## 8. Database design
Tables: `users`, `activities`, `habits`, `habit_logs`, `tasks` (see `database/schema.sql`).

```mermaid
erDiagram
  users ||--o{ activities : logs
  users ||--o{ habits : owns
  users ||--o{ tasks : plans
  habits ||--o{ habit_logs : "completed on"
```
- Each table has an integer primary key; child tables reference `users` (or `habits`) with foreign keys and `ON DELETE CASCADE`.
- Normalization: no repeating groups or transitive dependencies (3NF). Habit completions are in their own table instead of a column per day.
- Constraints: UNIQUE username/email, ENUM for category and priority, CHECK on duration, UNIQUE (habit_id, log_date) to prevent double completion.

## 9. Module descriptions
- **Authentication:** register, login, logout, hashed passwords, session handling.
- **Activities:** create, list with filter, edit, delete.
- **Habits:** create, toggle last 7 days, completion %, streak, delete.
- **Tasks:** create, edit, complete, delete, overdue flag.
- **Analytics:** totals, 7-day average, best day, four charts.

## 10. Implementation details
- **Parameterized SQL:** all queries pass values separately, which blocks SQL injection.
- **Ownership checks:** every UPDATE/DELETE includes `AND user_id = %s`, so a user cannot modify another user's rows.
- **Password security:** `generate_password_hash` / `check_password_hash`.
- **CSRF:** a random token in the session must match a hidden form field on every POST.
- **Validation:** server-side validators in `utils/validators.py`; HTML attributes give early feedback.
- **Habit completion %:** completed days ÷ days since the habit was created (capped at 100).
- **Streak:** consecutive completed days counting back from today (or yesterday if today is not yet done).
- **Charts:** Matplotlib with the Agg backend; each chart is queried from the database and saved as a per-user PNG.

## 11. Screenshots and outputs
_Add screenshots from `screenshots/`: login, register, dashboard, activities, habits, tasks._

## 12. Testing
- Unit tests (`pytest`): validators, completion percentage and streak logic.
- Manual test cases to record in a table before submission: register with invalid data, duplicate registration, wrong password, add/edit/delete activity, future date rejected, habit toggle twice, task overdue flag, user A cannot open user B's record (404), empty dashboard for a new user.

## 13. Limitations
- Charts are static images (click to enlarge), not live-updating.
- No password reset or email verification.
- Habits are tick-based for the last 7 days only.
- Single-server deployment; no automated browser tests.

## 14. Future scope
Password reset, CSV export, weekly goals, reminders, mobile app, interactive charts with a JavaScript library.

## 15. Conclusion
The project delivers a working multi-user productivity tracker where every statistic and chart comes from database records, using a modular and secure Flask design.

## 16. References
- Flask documentation: https://flask.palletsprojects.com
- MySQL 8.0 Reference Manual: https://dev.mysql.com/doc/
- Matplotlib documentation: https://matplotlib.org
- OWASP Top 10 and CSRF Prevention Cheat Sheet: https://owasp.org

## 17. Individual contributions
**Piyush Bisht (Primary Developer):** project planning and architecture; Flask backend; MySQL schema and integration; authentication, activities and habits modules; analytics and Matplotlib; application integration; GitHub repository; final testing and documentation coordination.

**Naman (Supporting Developer):** frontend assistance with HTML/CSS; assistance with the task management module; UI testing and bug reporting; screenshot collection; README and documentation assistance.

_Edit this section to match what each of you actually did before you submit._
